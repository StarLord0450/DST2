import LegalLayout from "@/components/legal/legal-layout";

export const metadata = {
  title: "Shipping Policy | DropshipTroopers",
};

export default function ShippingPolicyPage() {
  return (
    <LegalLayout title="Shipping Policy" updated="[DATE]">
      <section>
        <h2>Processing Time</h2>
        <p>
          All orders are processed within 1–3 business days after payment is
          confirmed. Orders are not shipped or delivered on weekends or
          holidays.
        </p>
      </section>

      <section>
        <h2>Shipping Rates &amp; Delivery Estimates</h2>
        <p>
          Shipping charges are calculated and displayed at checkout.
          Estimated delivery times:
        </p>
        <table>
          <thead>
            <tr>
              <th>Method</th>
              <th>Estimated Delivery</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Standard Shipping</td>
              <td>10–20 business days</td>
            </tr>
            <tr>
              <td>Expedited Shipping (if available)</td>
              <td>5–10 business days</td>
            </tr>
          </tbody>
        </table>
        <p>
          Delivery delays can occasionally occur due to customs processing,
          carrier delays, or high demand. We appreciate your patience.
        </p>
      </section>

      <section>
        <h2>Order Tracking</h2>
        <p>
          Once your order ships, you&apos;ll receive a confirmation email with
          a tracking number. Please allow 24–48 hours for tracking
          information to update.
        </p>
      </section>

      <section>
        <h2>Customs, Duties &amp; Taxes</h2>
        <p>
          DropshipTroopers is not responsible for any customs and taxes
          applied to your order. All fees imposed during or after shipping
          are the responsibility of the customer.
        </p>
      </section>

      <section>
        <h2>International Shipping</h2>
        <p>
          We currently ship to select international destinations.
          International orders may be subject to import duties and taxes,
          which are the buyer&apos;s responsibility.
        </p>
      </section>

      <section>
        <h2>Lost or Missing Packages</h2>
        <p>
          If your tracking shows delivered but you haven&apos;t received your
          package, please contact your local carrier first, then reach out to
          us at{" "}
          <a href="mailto:support@yourdomain.com">support@yourdomain.com</a>{" "}
          and we&apos;ll help investigate.
        </p>
      </section>

      <section>
        <h2>Contact</h2>
        <p>
          Questions about your shipment? Email{" "}
          <a href="mailto:support@yourdomain.com">support@yourdomain.com</a>{" "}
          with your order number.
        </p>
      </section>
    </LegalLayout>
  );
}
