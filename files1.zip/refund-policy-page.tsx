import LegalLayout from "@/components/legal/legal-layout";

export const metadata = {
  title: "Refund & Return Policy | DropshipTroopers",
};

export default function RefundPolicyPage() {
  return (
    <LegalLayout title="Refund & Return Policy" updated="[DATE]">
      <section>
        <h2>Overview</h2>
        <p>
          At DropshipTroopers, we want you to be happy with your purchase.
          Please read our policy carefully, as fulfillment times can vary due
          to the nature of our supply chain.
        </p>
      </section>

      <section>
        <h2>Order Processing</h2>
        <p>
          Orders are typically processed within 1–3 business days. You will
          receive a confirmation email with tracking information once your
          order ships.
        </p>
      </section>

      <section>
        <h2>Shipping Times</h2>
        <p>
          Due to international fulfillment, delivery can take 7–20 business
          days depending on your location and the product ordered. Delays
          beyond our control (customs, carrier delays) are not eligible for
          refund on shipping grounds alone.
        </p>
      </section>

      <section>
        <h2>Returns</h2>
        <p>We accept returns within 14 days of delivery for:</p>
        <ul>
          <li>Items that arrive damaged or defective</li>
          <li>Items that are significantly not as described</li>
          <li>Incorrect items received</li>
        </ul>
        <p>
          To request a return, email{" "}
          <a href="mailto:support@yourdomain.com">support@yourdomain.com</a>{" "}
          with your order number and photos of the issue. We will respond
          within 2 business days with next steps.
        </p>
      </section>

      <section>
        <h2>Non-Returnable Items</h2>
        <ul>
          <li>Items damaged due to customer misuse</li>
          <li>Change-of-mind returns after 14 days</li>
          <li>Final sale / clearance items (if applicable)</li>
        </ul>
      </section>

      <section>
        <h2>Refunds</h2>
        <p>
          Once your return is received and inspected, we will notify you of
          approval status. Approved refunds are credited to your original
          payment method within 5–10 business days.
        </p>
      </section>

      <section>
        <h2>Cancellations</h2>
        <p>
          Orders can be cancelled within 12 hours of purchase, before they are
          sent to our fulfillment partner. After this window, the order may
          already be in processing and cannot be cancelled.
        </p>
      </section>

      <section>
        <h2>Contact</h2>
        <p>
          Questions about returns or refunds? Email us at{" "}
          <a href="mailto:support@yourdomain.com">support@yourdomain.com</a>.
        </p>
      </section>
    </LegalLayout>
  );
}
