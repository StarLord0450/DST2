import LegalLayout from "@/components/legal/legal-layout";

export const metadata = {
  title: "Privacy Policy | DropshipTroopers",
};

export default function PrivacyPolicyPage() {
  return (
    <LegalLayout title="Privacy Policy" updated="[DATE]">
      <p>
        DropshipTroopers (&quot;we&quot;, &quot;us&quot;, &quot;our&quot;)
        operates yourdomain.com. This Privacy Policy explains how we collect,
        use, and protect your information when you use our site.
      </p>

      <section>
        <h2>Information We Collect</h2>
        <ul>
          <li>
            <strong>Contact information</strong>: name, email, shipping
            address, phone number
          </li>
          <li>
            <strong>Payment information</strong>: processed securely via
            Stripe — we do not store your full card details
          </li>
          <li>
            <strong>Order information</strong>: items purchased, order
            history
          </li>
          <li>
            <strong>Usage data</strong>: pages visited, browser type, device
            info (via analytics/cookies)
          </li>
        </ul>
      </section>

      <section>
        <h2>How We Use Your Information</h2>
        <ul>
          <li>To process and fulfill your orders</li>
          <li>To communicate order updates and respond to support requests</li>
          <li>To improve our website and product offerings</li>
          <li>To send marketing communications, only if you opt in</li>
        </ul>
      </section>

      <section>
        <h2>Third-Party Services</h2>
        <p>
          We share information with trusted third parties strictly to operate
          our store:
        </p>
        <ul>
          <li>
            <strong>Stripe</strong> — payment processing
          </li>
          <li>
            <strong>Supabase</strong> — order and customer data storage
          </li>
          <li>
            <strong>CJDropshipping</strong> — order fulfillment and shipping
          </li>
          <li>
            <strong>Vercel</strong> — website hosting
          </li>
        </ul>
        <p>
          These providers only receive the information necessary to perform
          their function and are contractually bound to protect it.
        </p>
      </section>

      <section>
        <h2>Cookies</h2>
        <p>
          We use cookies to keep your cart functional and to understand site
          usage. You can disable cookies in your browser settings, though this
          may affect site functionality.
        </p>
      </section>

      <section>
        <h2>Data Retention</h2>
        <p>
          We retain order and account data as long as necessary to comply
          with legal, tax, and accounting requirements.
        </p>
      </section>

      <section>
        <h2>Your Rights</h2>
        <p>
          You may request access to, correction of, or deletion of your
          personal data at any time by emailing{" "}
          <a href="mailto:support@yourdomain.com">support@yourdomain.com</a>.
        </p>
      </section>

      <section>
        <h2>Children&apos;s Privacy</h2>
        <p>
          Our site is not intended for children under 13. We do not knowingly
          collect data from children.
        </p>
      </section>

      <section>
        <h2>Changes to This Policy</h2>
        <p>
          We may update this policy periodically. Changes will be posted on
          this page with an updated &quot;last updated&quot; date.
        </p>
      </section>

      <section>
        <h2>Contact</h2>
        <p>
          Questions about this policy? Email{" "}
          <a href="mailto:support@yourdomain.com">support@yourdomain.com</a>.
        </p>
      </section>
    </LegalLayout>
  );
}
