import Link from "next/link";

export default function LegalLayout({
  title,
  updated,
  children,
}: {
  title: string;
  updated: string;
  children: React.ReactNode;
}) {
  return (
    <main className="min-h-screen bg-zinc-950 text-zinc-200">
      <div className="mx-auto max-w-3xl px-6 py-16">
        <Link
          href="/"
          className="text-sm text-cyan-500 hover:text-cyan-400 transition-colors"
        >
          ← Back to DropshipTroopers
        </Link>

        <h1 className="mt-6 text-3xl font-bold tracking-tight text-white">
          {title}
        </h1>
        <p className="mt-2 text-sm text-zinc-500">Last updated: {updated}</p>

        <div className="mt-10 space-y-8 text-zinc-300 leading-relaxed [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:text-white [&_h2]:mt-8 [&_h2]:mb-3 [&_a]:text-cyan-500 [&_a]:hover:text-cyan-400 [&_strong]:text-white [&_table]:w-full [&_table]:border-collapse [&_th]:text-left [&_th]:border-b [&_th]:border-zinc-800 [&_th]:pb-2 [&_td]:border-b [&_td]:border-zinc-900 [&_td]:py-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ul]:space-y-1">
          {children}
        </div>
      </div>
    </main>
  );
}
