import Link from "next/link";
import LegalLayout from "@/components/legal/legal-layout";

export const metadata = {
  title: "Terms of Service | DropshipTroopers",
};

export default function TermsOfServicePage() {
  return (
    <LegalLayout title="Terms of Service" updated="[DATE]">
      <p>
        Welcome to DropshipTroopers. By accessing or using our website, you
        agree to these Terms of Service.
      </p>

      <section>
        <h2>1. Overview</h2>
        <p>
          DropshipTroopers (&quot;we&quot;, &quot;us&quot;) sells products via
          our online store at yourdomain.com. Products are fulfilled through
          third-party suppliers, and shipping times reflect this arrangement.
        </p>
      </section>

      <section>
        <h2>2. Orders &amp; Payment</h2>
        <p>
          All prices are listed in USD unless otherwise noted. Payment is
          processed securely via Stripe at the time of order. We reserve the
          right to refuse or cancel any order for reasons including but not
          limited to product availability, errors in pricing, or suspected
          fraud.
        </p>
      </section>

      <section>
        <h2>3. Shipping</h2>
        <p>
          See our <Link href="/shipping-policy">Shipping Policy</Link> for
          delivery estimates. We are not liable for delays caused by customs,
          carriers, or events outside our control.
        </p>
      </section>

      <section>
        <h2>4. Returns &amp; Refunds</h2>
        <p>
          See our <Link href="/refund-policy">Refund &amp; Return Policy</Link>{" "}
          for full details on eligibility and process.
        </p>
      </section>

      <section>
        <h2>5. Product Accuracy</h2>
        <p>
          We strive to accurately display product details, but slight
          variations in color, size, or packaging may occur due to supplier
          and manufacturing differences.
        </p>
      </section>

      <section>
        <h2>6. Limitation of Liability</h2>
        <p>
          DropshipTroopers is not liable for any indirect, incidental, or
          consequential damages arising from the use of our products or
          website.
        </p>
      </section>

      <section>
        <h2>7. Intellectual Property</h2>
        <p>
          All content on this site — logos, text, graphics, images — is the
          property of DropshipTroopers unless otherwise noted, and may not be
          reproduced without permission.
        </p>
      </section>

      <section>
        <h2>8. Governing Law</h2>
        <p>
          These terms are governed by the laws of [YOUR STATE/COUNTRY],
          without regard to conflict of law principles.
        </p>
      </section>

      <section>
        <h2>9. Changes to Terms</h2>
        <p>
          We may revise these Terms at any time. Continued use of the site
          after changes constitutes acceptance of the new terms.
        </p>
      </section>

      <section>
        <h2>10. Contact</h2>
        <p>
          Questions? Email{" "}
          <a href="mailto:support@yourdomain.com">support@yourdomain.com</a>.
        </p>
      </section>
    </LegalLayout>
  );
}
