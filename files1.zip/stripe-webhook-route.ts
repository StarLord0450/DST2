import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
});

// Service-role client — server-side only, bypasses RLS.
// Never expose this client or key to the browser.
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

export async function POST(req: NextRequest) {
  const body = await req.text();
  const signature = req.headers.get("stripe-signature");

  if (!signature) {
    return NextResponse.json({ error: "Missing signature" }, { status: 400 });
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err) {
    console.error("Webhook signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutCompleted(session);
        break;
      }

      case "payment_intent.payment_failed": {
        const intent = event.data.object as Stripe.PaymentIntent;
        console.warn("Payment failed:", intent.id);
        break;
      }

      default:
        // Unhandled event types are fine to ignore.
        break;
    }

    return NextResponse.json({ received: true });
  } catch (err) {
    console.error("Error handling webhook event:", err);
    // Return 500 so Stripe retries delivery.
    return NextResponse.json(
      { error: "Webhook handler failed" },
      { status: 500 }
    );
  }
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  // Retrieve line items since the session object alone doesn't include them.
  const lineItems = await stripe.checkout.sessions.listLineItems(session.id, {
    expand: ["data.price.product"],
  });

  const customerEmail =
    session.customer_details?.email ?? session.customer_email ?? null;

  const shippingAddress = session.shipping_details?.address ?? null;

  // 1. Insert the order.
  const { data: order, error: orderError } = await supabaseAdmin
    .from("orders")
    .insert({
      stripe_session_id: session.id,
      stripe_payment_intent: session.payment_intent as string,
      customer_email: customerEmail,
      amount_total: session.amount_total,
      currency: session.currency,
      status: "paid",
      shipping_address: shippingAddress,
    })
    .select()
    .single();

  if (orderError) {
    throw new Error(`Failed to create order: ${orderError.message}`);
  }

  // 2. Insert order line items.
  const orderItems = lineItems.data.map((item) => ({
    order_id: order.id,
    stripe_price_id: item.price?.id,
    product_name: item.description,
    quantity: item.quantity,
    amount_total: item.amount_total,
  }));

  const { error: itemsError } = await supabaseAdmin
    .from("order_items")
    .insert(orderItems);

  if (itemsError) {
    throw new Error(`Failed to create order items: ${itemsError.message}`);
  }

  // 3. TODO: trigger CJDropshipping fulfillment here once that
  // integration is built. For now, orders land in Supabase with
  // status "paid" and can be fulfilled manually via the CJ dashboard.

  console.log(`Order ${order.id} created for session ${session.id}`);
}

// Stripe requires the raw body for signature verification,
// so disable Next.js's default body parsing for this route.
export const config = {
  api: {
    bodyParser: false,
  },
};
